from flask import Flask, request, redirect
from os import access, R_OK, stat
from os.path import isfile, join, normpath
import regex

app = Flask(__name__, static_url_path='/static', static_folder='static')

@app.get('/')
def home():
	if request.args.get('file'):
		filename = join("./static", request.args.get('file'))
		if isfile(normpath(filename)) and access(normpath(filename), R_OK) and (stat(normpath(filename)).st_size < 1024 * 1024 * 2):
			try:
				with open(normpath(filename), "rb") as file:
					if not regex.search(r'^(([ -~])+.)+([(^~\'!*<>:;,?"*|%)]+)|([^\x00-\x7F]+)(([ -~])+.)+$', filename, timeout=2) and "flag" not in filename:
						return file.read(1024 * 1024 * 2)
			except:
				pass
	return redirect("/?file=index.html")
