let slideIndex = 0;
let currentSlideIndex = 0;
let slideArray = [];

function Slide(title, content, author, background, link ) {
	this.title = title;
	this.content = content;
	this.author = author;
	this.background = background;
	this.link = link;
	this.id = "slide" + slideIndex;
	slideIndex++;
	slideArray.push(this);
}

window.addEventListener('load', function () {
	fetch("/static/data.json").then(res => res.json()).then(data => {
		data?.map((item, index) => {
			new Slide(item?.title, item?.content, item?.author, item?.background, item?.link)
		})
		buildSlider();
		setInterval(() => {
			nextSlide();
		}, 60000)
	})
})

function buildSlider(){
	for(let i = 0; i < slideArray.length; i++) {
		let newDiv = document.createElement("div");
		newDiv.id = slideArray[i].id;
		newDiv.className = "singleSlide";
		newDiv.style.backgroundImage = "url(" + slideArray[i].background + ")";

		let newDivChild = document.createElement("div");
		newDivChild.className = "slideOverlay";			

		let newH1Child = document.createElement("h1");
		newH1Child.innerText = slideArray[i].title;
		newH1Child.style.lineHeight = "4.1365vh";

		let newNoteChild = document.createElement("i");
		newNoteChild.innerText = "(Trích)"

		let newH4Child = document.createElement("h4");
		newH4Child.innerText = slideArray[i].content;
		newH4Child.style.marginBottom = "1.55119vh";
		newH4Child.style.lineHeight = "3.92968vh";

		let newHrefChild = document.createElement("a");
		newHrefChild.href = slideArray[i].link;
		newHrefChild.target = "_blank";
		newHrefChild.innerText = "Tác giả: " + slideArray[i].author;
		newHrefChild.style.float = "right";
		newHrefChild.style.paddingTop = "unset";
		newHrefChild.style.paddingBottom = "unset";

		let divContainer = document.createElement("div");
		divContainer.style.maxWidth = "fit-content";
		divContainer.style.margin = "auto";

		divContainer.appendChild(newH1Child);
		divContainer.appendChild(newNoteChild)
		divContainer.appendChild(newH4Child);
		divContainer.appendChild(newHrefChild);
		newDivChild.appendChild(divContainer)

		newDiv.appendChild(newDivChild);	
		document.getElementById("mySliderChild").appendChild(newDiv);
	}
	
	document.getElementById("slide" + currentSlideIndex).style.left = 0;

}


function prevSlide(){
	let nextSlideIndex;
	if (currentSlideIndex === 0 ) {
		nextSlideIndex = slideArray.length - 1;
	} else {
		nextSlideIndex = currentSlideIndex - 1;
	}	
	
	document.getElementById("slide" + nextSlideIndex).style.left = "-100%";
	document.getElementById("slide" + currentSlideIndex).style.left = 0;
	document.getElementById("slide" + nextSlideIndex).setAttribute("class", "singleSlide slideInLeft");
	document.getElementById("slide" + currentSlideIndex).setAttribute("class", "singleSlide slideOutRight");
	
	currentSlideIndex = nextSlideIndex;
}


function nextSlide(){
	let nextSlideIndex;
	if (currentSlideIndex === (slideArray.length - 1) ) {
		nextSlideIndex = 0;
	} else {
		nextSlideIndex = currentSlideIndex + 1;
	}	
	
	document.getElementById("slide" + nextSlideIndex).style.left = "100%";
	document.getElementById("slide" + currentSlideIndex).style.left = 0;
	document.getElementById("slide" + nextSlideIndex).setAttribute("class", "singleSlide slideInRight");
	document.getElementById("slide" + currentSlideIndex).setAttribute("class", "singleSlide slideOutLeft");
	currentSlideIndex = nextSlideIndex;
}