const uuid = require('uuid')
const sha256 = require('js-sha256')
const fp = require('fastify-plugin')
const fastify = require('fastify')({
    ignoreTrailingSlash: true,
    logger: {
        level: 'info'
    }
})

await fastify.register(require('@fastify/env'), {
    schema: {
        type: 'object',
        required: ['FLAG', 'CONFIG_KEY', 'BROWSER_EXAM_KEY'],
        properties: {
            FLAG: {
                type: 'string',
                default: 'KCSC{test}'
            },
            CONFIG_KEY: {
                type: 'string',
                default: '0123456789abcdef'
            },
            BROWSER_EXAM_KEY: {
                type: 'string',
                default: '0123456789abcdef'
            }
        }
    }
})

await fastify.register(require('@fastify/helmet'), { global: true })
await fastify.register(require('@fastify/cookie'))
await fastify.register(require('@fastify/session'), {
    secret: [...Array(32)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')
})

await fastify.register(require('@fastify/static'), {
    root: require('node:path').join(__dirname, 'public'),
    prefix: '/public/',
})

const uuidb = new Map()

const calculateConfigKeyHash = (configKey, url) => {
    return sha256(url + configKey)
}

const calculateBrowserExamKeyHash = (broswerKey, url) => {
    return sha256(url + broswerKey)
}

await fastify.register(fp((fastify, opts, next) => {
    fastify.addHook('onRequest', async (req, reply) => {
        let configKeyHash = calculateConfigKeyHash(fastify.config.CONFIG_KEY, `http://${req.headers.host}:10003${req.url}`)
        let broswerExamKeyHash = calculateBrowserExamKeyHash(fastify.config.BROWSER_EXAM_KEY, `http://${req.headers.host}:10003${req.url}`)
        if (req.headers['x-safeexambrowser-configkeyhash'] !== configKeyHash || req.headers['x-safeexambrowser-requesthash'] !== broswerExamKeyHash) {
            reply.type('text/html').status(403).send('pls use on safe exam browser')
        }
    })
    next()
}))

fastify.get('/', function (request, reply) {
    reply.sendFile('index.html')
})

fastify.get('/get-flag', async function (request, reply) {
    let uuid4 = uuid.v4()
    await request.session.reload()
    await uuidb.set(request.session.sessionId, uuid4)
    await request.session.save()
    await reply.status(302).redirect(`/flag/${uuid4}`)
})

fastify.get('/flag/:uuid', function (request, reply) {
    let uuid = uuidb.get(request.session.sessionId)
    request.session.destroy()
    if (uuid === request.params.uuid) {
        reply.send(fastify.config.FLAG)
    } else {
        reply.status(401).send('forbidden')
    }
})

fastify.listen({ host: '0.0.0.0', port: 10003 })