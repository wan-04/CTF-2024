from flask import Flask, request, render_template, flash
import zipfile
import re
import os
from os import listdir
from os.path import isfile, join

app = Flask(__name__, static_folder='uploads')
app.secret_key = "test_keyyyyyyy"

def list_all_files(mypath: str):
	output = []
	for path, subdirs, files in os.walk(mypath):
		for name in files:
			output.append(os.path.join(path, name))
	return output

def fileIsSafe(file_ext: str):
	if not file_ext:
		return False
	if re.match(r'\.(py|ini|html|htm|env|bash|sh|so|preload)', file_ext):
		return False
	return True

@app.route('/')
def index():
	mypath = "uploads"
	uploaded_file = list_all_files(mypath)
	return render_template('index.html', data = uploaded_file)

@app.route('/upload', methods=['POST'])
def upload():
	if not request.files['file']:
		return "Not file provided"
	else:
		try:
			client_file = request.files['file']
			with zipfile.ZipFile(client_file, 'r') as zip_ref:
				for name in zip_ref.namelist():
					_, file_ext = os.path.splitext(name)
					if fileIsSafe(file_ext):
						if len(name.split("/")) != 1:
							curr_path = "uploads"
							for folder_name in name.split("/")[:-1]:
								 curr_path += f"/{folder_name}"
								 if not os.path.exists(curr_path):
									 os.mkdir(curr_path)
						dest_path = os.path.normpath(f"uploads/{name}")
						with open(dest_path, "wb") as f:
							f.write(zip_ref.read(name))
		except:
			return "Something went wrong"
	return "Success! Check uploads/ folder"

@app.route('/healthz')
def healthz():
	import subprocess
	output = subprocess.check_output(["python", "-c", "print('OK')"])
	return output
	
if __name__ == "__main__":
	app.run(host="0.0.0.0", debug=False, port=5000)