import io
import pickle

unsafe_builtins = [
  "exec",
  "eval",
  "__import__"
]

def is_safe(module, name):
  if module == "builtins" and name not in unsafe_builtins:
    return True
  return False

class RestrictedUnpickler(pickle.Unpickler):
  def find_class(self, module, name):
    if is_safe(module, name):
      return super().find_class(module, name)
    else:
      raise pickle.UnpicklingError("'%s.%s' is forbidden" % (module, name))


def restricted_loads(s):
  return RestrictedUnpickler(io.BytesIO(s)).load()