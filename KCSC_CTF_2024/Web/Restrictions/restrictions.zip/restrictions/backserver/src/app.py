from flask import Flask, request, render_template
from utils import restricted_loads
import base64

app = Flask(__name__)
app.config.from_object("config.Config")

@app.route("/")
def index():
  return render_template("index.html")

@app.route("/pickme", methods = ["GET", "POST"])
def pickme():
  if request.method == "POST":
    restricted_loads(base64.b64decode(request.form["pick"]))
    return "", 200
  return render_template("pick.html")

