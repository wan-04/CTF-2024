

threads = 2
bind = "0.0.0.0:9000"

accesslog = "-"
wsgi_app = "app:app"

