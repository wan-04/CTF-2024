<?
$menu["menu200"] = array (
    array("200000", "회원관리", ""),
    array("200100", "회원관리", "$g4[admin_path]/member_list.php"),
    array("200200", "포인트관리", "$g4[admin_path]/point_list.php"),
    array("200300", "회원메일발송", "$g4[admin_path]/mail_list.php"),
    array("-"),
    array("200800", "접속자현황", "$g4[admin_path]/visit_list.php"),
    array("200810", "접속자검색", "$g4[admin_path]/visit_search.php"),
    array("-"),
    array("200900", "투표관리", "$g4[admin_path]/poll_list.php")
);
?>