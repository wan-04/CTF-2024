chmod 707 .
chmod -R 707 data
