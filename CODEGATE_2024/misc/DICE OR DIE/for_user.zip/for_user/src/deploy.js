require('dotenv').config()
const { execSync } = require('child_process')
const rpc = 'https://public-en-baobab.klaytn.net'
const key = process.env.privKey
execSync('forge build --force --optimize --optimizer-runs 200', {
  encoding: 'utf8',
  cwd: 'onchain',
})
const usd = execSync(
  `forge create --private-key ${key} --rpc-url ${rpc} src/USD.sol:USD`,
  { encoding: 'utf8', cwd: 'onchain' }
)
  .split('\n')
  .filter((x) => x.includes('Deployed to: '))[0]
  .split(' ')[2]
const dd = execSync(
  `forge create --private-key ${key} --rpc-url ${rpc} src/DD.sol:DD --constructor-args ${usd}`,
  { encoding: 'utf8', cwd: 'onchain' }
)
  .split('\n')
  .filter((x) => x.includes('Deployed to: '))[0]
  .split(' ')[2]
execSync(
  `cast send --private-key ${key} --rpc-url ${rpc} ${usd} "addDice(address)" ${dd}`,
  {
    encoding: 'utf8',
    cwd: 'onchain',
  }
)
console.log(`USD: ${usd}`)
console.log(`DD: ${dd}`)
