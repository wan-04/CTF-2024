export const usdAddress = '0x30512445782Ae94eb1D21C8C4C4f493fFEa2982f'
export const ddAddress = '0x0A3E3E87C2B51469E56404459078e043B12e6cD6'
export const usdAbi = [
  {
    type: 'function',
    name: 'balanceOf',
    stateMutability: 'view',
    inputs: [{ name: 'account', type: 'address' }],
    outputs: [{ type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'totalSupply',
    stateMutability: 'view',
    inputs: [],
    outputs: [{ name: 'supply', type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'publicMint',
    inputs: [],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'error',
    name: 'ERC20InsufficientBalance',
    inputs: [
      { name: 'account', type: 'address', internalType: 'address' },
      { name: 'balance', type: 'uint256', internalType: 'uint256' },
      { name: 'value', type: 'uint256', internalType: 'uint256' },
    ],
  },
  {
    type: 'error',
    name: 'OnlyDice',
    inputs: [{ name: 'addr', type: 'address', internalType: 'address' }],
  },
  {
    type: 'error',
    name: 'TooFast',
    inputs: [
      { name: 'account', type: 'address', internalType: 'address' },
      { name: 'timestamp', type: 'uint256', internalType: 'uint256' },
    ],
  },
]
export const ddAbi = [
  {
    type: 'function',
    name: 'checkSolve',
    inputs: [{ name: 'id', type: 'bytes32', internalType: 'bytes32' }],
    outputs: [{ name: '', type: 'bool', internalType: 'bool' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'bet',
    inputs: [
      { name: 'index', type: 'uint256', internalType: 'uint256' },
      { name: 'value', type: 'uint256', internalType: 'uint256' },
      { name: 'size', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'buyFlag',
    inputs: [{ name: 'id', type: 'bytes32', internalType: 'bytes32' }],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'isSettled',
    inputs: [{ name: 'index', type: 'uint256', internalType: 'uint256' }],
    outputs: [{ name: '', type: 'bool', internalType: 'bool' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'open',
    inputs: [
      { name: 'index', type: 'uint256', internalType: 'uint256' },
      { name: 'commitment', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'commit',
    inputs: [
      { name: 'index', type: 'uint256', internalType: 'uint256' },
      { name: 'commitment', type: 'bytes32', internalType: 'bytes32' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'error',
    name: 'ERC20InsufficientBalance',
    inputs: [
      { name: 'account', type: 'address', internalType: 'address' },
      { name: 'balance', type: 'uint256', internalType: 'uint256' },
      { name: 'value', type: 'uint256', internalType: 'uint256' },
    ],
  },
  {
    type: 'error',
    name: 'InvalidCommitment',
    inputs: [{ name: 'commitment', type: 'uint256', internalType: 'uint256' }],
  },
  {
    type: 'error',
    name: 'InvalidSize',
    inputs: [{ name: 'size', type: 'uint256', internalType: 'uint256' }],
  },
  {
    type: 'error',
    name: 'OnlyOwner',
    inputs: [{ name: 'account', type: 'address', internalType: 'address' }],
  },
  {
    type: 'error',
    name: 'TooRich',
    inputs: [{ name: 'account', type: 'address', internalType: 'address' }],
  },
  { type: 'event', name: 'Lose', inputs: [], anonymous: false },
  {
    type: 'event',
    name: 'Win',
    inputs: [
      {
        name: 'amount',
        type: 'uint256',
        indexed: true,
        internalType: 'uint256',
      },
    ],
    anonymous: false,
  },
]

export const Color = {
  white: '#FFFFFF',
  black2: '#F0F1F5',
  black3: '#DDDFE5',
  black4: '#A4A8B7',
  black5: '#868C9E',
  black6: '#6B7184',
  black7: '#50566B',
  black8: '#363C51',
  black9: '#16192A',
  black10: '#00000E',
}

export const Font = {
  heading1: { fontSize: '2rem', fontWeight: 'extrabold' },
  heading2: { fontSize: '1.75rem', fontWeight: 'bold' },
  heading3: { fontSize: '1.5rem', fontWeight: 'bold' },
  heading4: { fontSize: '1.5rem', fontWeight: 'semibold' },
  title1: { fontSize: '1.25rem', fontWeight: 'bold' },
  title2: { fontSize: '1.125rem', fontWeight: 'bold' },
  title3: { fontSize: '1rem', fontWeight: 'bold' },
  title4: { fontSize: '1.125rem', fontWeight: 'semibold' },
  title5: { fontSize: '1rem', fontWeight: 'semibold' },
  body1: { fontSize: '1.125rem', fontWeight: 'medium' },
  body2: { fontSize: '1rem', fontWeight: 'medium' },
  body3: { fontSize: '0.9375rem', fontWeight: 'medium' },
  body4: { fontSize: '0.875rem', fontWeight: 'medium' },
  caption: { fontSize: '0.75rem', fontWeight: 'medium' },
}
