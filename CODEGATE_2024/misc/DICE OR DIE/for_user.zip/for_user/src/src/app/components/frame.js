'use client'
import Menu from '@/app/components/menu'
import { Color } from '@/constants'
import {
  Flex,
  Modal,
  ModalOverlay,
  Spinner,
  VStack,
  useDisclosure,
  useToast,
} from '@chakra-ui/react'
import { useSearchParams } from 'next/navigation'
import { useEffect } from 'react'

export default function Page({ children }) {
  const toast = useToast()
  const id = useSearchParams().get('id')

  useEffect(() => {
    const localId = localStorage.getItem('id')
    if (localId === null && id?.length === 66) localStorage.setItem('id', id)
    window.toast = toast
    window.id = localId
  }, [id, toast])

  return (
    <main>
      <Flex justify='center' background={Color.black10} color={Color.white}>
        <VStack align='stretch' minWidth='1440px' minHeight='100vh'>
          <Menu />
          {children}
          <GlobalSpinner />
        </VStack>
      </Flex>
    </main>
  )
}

function GlobalSpinner() {
  const { isOpen, onOpen, onClose } = useDisclosure()
  useEffect(() => {
    window.spinOn = onOpen
    window.spinOff = onClose
  }, [onOpen, onClose])
  return (
    <Modal isOpen={isOpen}>
      <ModalOverlay />
      <Spinner
        style={{
          position: 'fixed',
          left: '50%',
          top: '40%',
          transform: 'translate(-50%, 50%)',
        }}
        size='xl'
      />
    </Modal>
  )
}
