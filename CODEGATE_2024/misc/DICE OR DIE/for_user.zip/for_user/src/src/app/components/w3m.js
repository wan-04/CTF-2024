'use client'

export default function Page() {
  return <w3m-button />
}
