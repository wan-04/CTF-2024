import { ddAddress } from '@/constants'
import { readFileSync } from 'fs'
import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import {
  createWalletClient,
  getContract,
  http,
  keccak256,
  publicActions,
  toBytes,
} from 'viem'
import { privateKeyToAccount } from 'viem/accounts'
import { klaytnBaobab } from 'viem/chains'

const loadMetadata = (name) =>
  JSON.parse(readFileSync(`onchain/out/${name}.sol/${name}.json`, 'utf8'))

const getRandom = () =>
  BigInt(Math.random().toString().slice(2)) *
  BigInt(Math.random().toString().slice(2))

export async function GET() {
  const header = headers()
  if (header.get('host') === '127.0.0.1:3000') {
    const dd = loadMetadata('DD')
    const account = privateKeyToAccount(process.env.privKey)
    const client = createWalletClient({
      account,
      chain: klaytnBaobab,
      transport: http(),
    }).extend(publicActions)

    const ddContract = getContract({
      address: ddAddress,
      abi: dd.abi,
      client,
    })

    const value = getRandom()
    const index = getRandom().toString()
    const commitment = keccak256(toBytes(value, { size: 32 }))
    const hash = await ddContract.write.commit([index, commitment])
    process.env[index] = value.toString()
    return NextResponse.json({
      index,
      commitment,
      hash,
      value: value.toString(),
    })
  }
  return NextResponse.json({ error: 'access denied' })
}
