'use client'

import { Flex, Image, VStack } from '@chakra-ui/react'

export default function Home() {
  return (
    <VStack>
      <Image src='/back.png' alt='dice' width='90%' />
      <Flex justify='center' w='1400px' mt='2rem'>
        Hello everyone!
        <br />
        <br />
        While earning money through hard work is certainly rewarding, imagine
        the thrill of winning money effortlessly through a game of chance!
        That&apos;s exactly what our &apos;Dice of Die&apos; offers – the
        excitement and joy of earning big through sheer luck.
        <br />
        <br />
        In our game, every roll of the dice brings you closer to that
        exhilarating moment when fortune smiles upon you. It&apos;s not just
        about the potential for high rewards, but also the fun and thrill of the
        game itself. With each roll, you have the chance to turn your luck into
        real, tangible earnings.
        <br />
        <br />
        So why not take a break from the usual grind and try your luck? Join our
        DeFi dice game, where a lucky roll could change everything. After all,
        there&apos;s nothing quite like the joy of easy winnings through a
        simple, yet thrilling, game of dice.
        <br />
        <br />
        May luck be on your side!
        <br />
        <br />
        Dice of Die Team
      </Flex>
    </VStack>
  )
}
