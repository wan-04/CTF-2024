'use client'
import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Box,
} from '@chakra-ui/react'

export default function Page() {
  return (
    <Accordion w='1440px'>
      <AccordionItem>
        <h2>
          <AccordionButton>
            <Box as='span' flex='1' textAlign='left'>
              Dear White Hacker
            </Box>
            <AccordionIcon />
          </AccordionButton>
        </h2>
        <AccordionPanel pb={4}>
          We recently experienced a security breach on our DeFi dice gambling,
          resulting in a significant loss of funds. We understand the
          sophistication and skill required to execute such an attack, and while
          we do not condone unauthorized access, we recognize the talent
          involved.
          <br />
          <br />
          In the spirit of collaboration and the growth of a secure blockchain
          ecosystem, we are extending an offer to you:
          <br />
          <br />
          If you return 90% of the stolen funds, we will reward you with 10% as
          a White Hat bounty. This gesture acknowledges your skills and provides
          an opportunity for a positive resolution to this incident.
          <br />
          <br />
          Our primary goal is to protect our users and maintain the integrity of
          our platform. By accepting this offer, you can contribute to a more
          secure and trustworthy DeFi community. Additionally, this action will
          prevent any legal consequences and enhance your reputation as a
          skilled security expert.
          <br />
          <br />
          To proceed with the return and reward process, please contact us at
          dice@dice.onchain.kr within the next 48 hours. We are open to
          discussing further steps to ensure a smooth transaction and address
          any concerns you may have.
          <br />
          <br />
          To our valued users, we want to assure you that the vulnerable code
          has been securely patched, and you can continue to use our platform
          with confidence. Your security and trust are our top priorities.
          <br />
          <br />
          We hope for a cooperative resolution and look forward to your
          response.
          <br />
          <br />
          Sincerely,
          <br />
          <br />
          Dice or Die Team
        </AccordionPanel>
      </AccordionItem>

      <AccordionItem>
        <h2>
          <AccordionButton>
            <Box as='span' flex='1' textAlign='left'>
              We are live! 🎲🎉
            </Box>
            <AccordionIcon />
          </AccordionButton>
        </h2>
        <AccordionPanel pb={4}>
          Hello everyone!
          <br />
          <br /> We are thrilled to announce the launch of our new DeFi dice
          gambling &quot;Dice or Die&quot;! 🎲🎉
          <br />
          <br /> Now, you can enjoy dice gambling safely and transparently using
          blockchain technology. Our platform offers an easy and intuitive user
          interface, with various betting options and the chance to earn high
          rewards.
          <br />
          <br />
          Why choose our site?
          <br />
          <br />
          1. Fairness and Transparency: Utilizing Web3 smart contracts, all
          games are conducted fairly and transparently. Everyone can verify the
          results, ensuring no possibility of manipulation.
          <br />
          <br />
          2. High Rewards: With various payout rates and betting options, you
          have the opportunity to earn more money.
          <br />
          <br />
          3. Secure Transactions: All transactions are securely protected using
          blockchain technology.
          <br />
          <br />
          4. Fast Deposits and Withdrawals: Our quick and easy deposit and
          withdrawal service allows you to manage your funds freely at any time.
          <br />
          <br />
          The more you participate, the more our platform grows, enabling us to
          provide even more benefits. Spread the word to your friends and
          don&apos;t miss out on the opportunity to earn money together!
          <br />
          <br />
          Sign up now and start your journey of luck! 🤑💰
          <br />
          <br />
          Thank you.
          <br />
          <br />
          Dice or Die Team
        </AccordionPanel>
      </AccordionItem>
    </Accordion>
  )
}
