'use server'
import { ddAbi, ddAddress } from '@/constants'
import { redirect } from 'next/navigation'
import { createPublicClient, http } from 'viem'
import { klaytnBaobab } from 'viem/chains'

export async function reveal(index) {
  if (!index) return redirect('/dice')

  const client = createPublicClient({
    chain: klaytnBaobab,
    transport: http(),
  })

  const result = await client.readContract({
    address: ddAddress,
    abi: ddAbi,
    functionName: 'isSettled',
    args: [index],
  })

  if (result) return process.env[index]
}
