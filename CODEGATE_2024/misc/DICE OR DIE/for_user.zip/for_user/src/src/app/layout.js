import { Provider } from '@/app/provider'
import { config } from '@/config'
import { Orbitron } from 'next/font/google'
import { headers } from 'next/headers'
import { cookieToInitialState } from 'wagmi'
import './global.css'

const font = Orbitron({ subsets: ['latin'] })

export const metadata = {
  title: 'Dice or Die',
  description: 'Make money playing dice games',
}

export default function RootLayout({ children }) {
  const initialState = cookieToInitialState(config, headers().get('cookie'))
  return (
    <html>
      <body className={font.className}>
        <Provider initialState={initialState}>{children}</Provider>
      </body>
    </html>
  )
}
