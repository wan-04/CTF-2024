import { use } from 'react'
import Main from './main'

export default function Page() {
  const { index } = use(
    fetch('http://127.0.0.1:3000/admin', {
      method: 'GET',
      cache: 'no-store',
    }).then((res) => res.json())
  )
  return <Main index={index} />
}
