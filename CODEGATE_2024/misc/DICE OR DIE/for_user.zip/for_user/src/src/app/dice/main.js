'use client'
import { reveal } from '@/app/actions'
import { ddAbi, ddAddress, usdAbi, usdAddress } from '@/constants'
import {
  Box,
  Button,
  Divider,
  Flex,
  HStack,
  Image,
  Input,
  List,
  ListItem,
  Text,
  VStack,
} from '@chakra-ui/react'
import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { useAccount, useReadContract, useWriteContract } from 'wagmi'

export default function Page({ index }) {
  let balance = 0
  const [history, setHistory] = useState([])
  const [id, setId] = useState('unknown')
  const betAmount = useRef()
  const [number, setNumber] = useState(0)
  const { address, isConnected } = useAccount()
  const { writeContractAsync } = useWriteContract()

  const rollDice = () => {
    const dice = document.querySelector('.die-list')
    toggleClasses(dice)
    dice.dataset.roll = getRandomNumber(1, 6)
    setNumber(dice.dataset.roll)
  }

  const toggleClasses = (die) => {
    die.classList.toggle('odd-roll')
    die.classList.toggle('even-roll')
  }

  const getRandomNumber = (min, max) => {
    min = Math.ceil(min)
    max = Math.floor(max)
    return Math.floor(Math.random() * (max - min + 1)) + min
  }

  const max = (bal) => {
    betAmount.current.value = bal
  }

  const mint = async () => {
    try {
      const hash = await writeContractAsync({
        abi: usdAbi,
        address: usdAddress,
        functionName: 'publicMint',
      })
      window.toast({
        title: 'Minting in progress',
        description: (
          <Link
            target='_blank'
            href={`https://baobab.klaytnscope.com/tx/${hash}`}
          >
            {hash}
          </Link>
        ),
        status: 'info',
        duration: 5000,
        isClosable: true,
      })
    } catch (e) {
      window.toast({
        title: 'Minting error',
        description: 'You are too fast. minting allowed once a day!',
        status: 'error',
        duration: 5000,
        isClosable: true,
      })
    }
  }

  const open = async (k, i) => {
    const commitment = await reveal.bind(null, i)()
    const hash = await writeContractAsync({
      abi: ddAbi,
      address: ddAddress,
      functionName: 'open',
      args: [i, commitment],
    })
    const newHistory = { ...history }
    delete newHistory[k]
    setHistory(newHistory)
    localStorage.setItem('history', JSON.stringify(newHistory))
    window.toast({
      title: 'Betting Open in progress',
      description: (
        <Link
          target='_blank'
          href={`https://baobab.klaytnscope.com/tx/${hash}`}
        >
          {hash}
        </Link>
      ),
      status: 'info',
      duration: 5000,
      isClosable: true,
    })
  }

  const bet = async () => {
    const amount = parseInt(betAmount.current.value)
    if (amount > 0) {
      const hash = await writeContractAsync({
        abi: ddAbi,
        address: ddAddress,
        functionName: 'bet',
        args: [index, number - 1, amount],
      })
      const newHistory = { ...history }
      newHistory[hash] = index
      localStorage.setItem('history', JSON.stringify(newHistory))
      setHistory(newHistory)
    }
  }

  const usdBalance = useReadContract({
    abi: usdAbi,
    address: usdAddress,
    functionName: 'balanceOf',
    args: [address],
  })

  if (typeof usdBalance?.data == 'bigint') balance = usdBalance.data.toString()

  useEffect(() => {
    if (window.id) setId(window.id)
    setHistory(JSON.parse(localStorage.getItem('history') ?? '{}'))
  }, [])

  return isConnected ? (
    <VStack mt='8rem'>
      <VStack>
        <Text>Your ID : {id}</Text>
        <HStack>
          <Text>Current Balance : {balance}</Text>
          <Image src='/usd.png' alt='usd' w='1.5rem' />
        </HStack>
        <Button onClick={mint}>mint</Button>
      </VStack>
      <Divider />
      <Box className='dice' mt='2rem'>
        <List className='die-list even-roll' data-roll='1' id='die-1'>
          {[...Array(6)].map((_, i) => (
            <ListItem className='die-item' data-side={i + 1} key={i}>
              {[...Array(i + 1)].map((_, j) => (
                <Flex className='dot' key={j} />
              ))}
            </ListItem>
          ))}
        </List>
      </Box>
      <Button onClick={rollDice}>Roll Dice</Button>
      <VStack mt='3rem'>
        <Flex>Your number is : {number}</Flex>
        <HStack>
          <Input type='number' placeholder='Bet amount' ref={betAmount} />
          <Button onClick={() => max(balance)}>Max</Button>
        </HStack>
        <Button isDisabled={number == 0} onClick={bet}>
          Bet!
        </Button>
      </VStack>
      <Divider />
      <VStack mt='2rem'>
        <Text>Your betting history</Text>
        <VStack>
          {Object.keys(history).map((k, i) => (
            <HStack key={i}>
              <Link
                target='_blank'
                href={`https://baobab.klaytnscope.com/tx/${k}`}
              >
                {k}
              </Link>
              <Button onClick={() => open(k, history[k])}>Open</Button>
            </HStack>
          ))}
        </VStack>
      </VStack>
    </VStack>
  ) : (
    <Flex justify='center'>connect first!</Flex>
  )
}
