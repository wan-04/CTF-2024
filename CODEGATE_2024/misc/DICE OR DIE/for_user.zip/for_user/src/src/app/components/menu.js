'use client'
import Web3Modal from '@/app/components/w3m'
import { Color } from '@/constants'
import { Link } from '@chakra-ui/next-js'
import { Flex, HStack, Image } from '@chakra-ui/react'

export default function Menu() {
  return (
    <Flex h='3.875rem' py='1.25rem'>
      <Flex w='25%'>
        <Image src='/dice.png' alt='dice' />
        <Link href='/' fontSize='1.25rem' _hover={onHoverText}>
          Dice or Die
        </Link>
        <Image src='/dice.png' alt='dice' />
      </Flex>
      <HStack w='50%' justify='center' spacing='4.25rem'>
        {menus.map((name) => (
          <Link href={`/${name.toLowerCase()}`} _hover={onHoverText} key={name}>
            {name}
          </Link>
        ))}
      </HStack>
      <Flex w='25%' justify='end'>
        <Web3Modal />
      </Flex>
    </Flex>
  )
}

const menus = ['Dice', 'Notice']
const onHoverText = { textDecoration: 'none', color: Color.black3 }
