import { ddAbi, ddAddress } from '@/constants'
import { NextResponse } from 'next/server'
import { createPublicClient, http } from 'viem'
import { klaytnBaobab } from 'viem/chains'

export async function GET({ nextUrl }) {
  const id = nextUrl.searchParams.get('id')
  if (id === null || id.length !== 66)
    return NextResponse.json({ result: false })

  const client = createPublicClient({
    chain: klaytnBaobab,
    transport: http(),
  })

  const result = await client.readContract({
    address: ddAddress,
    abi: ddAbi,
    functionName: 'checkSolve',
    args: [id],
  })

  return NextResponse.json({ result })
}
