import { cookieStorage, createConfig, createStorage, http } from 'wagmi'
import { klaytnBaobab } from 'wagmi/chains'
import { injected, walletConnect } from 'wagmi/connectors'

export const projectId = '2a701feaaaf99d4c3c399908032fd5f2'

const metadata = {
  name: 'Dice or Die',
  description: 'Make money playing dice games',
  url: 'https://dice.onchain.kr',
  icons: ['https://avatars.githubusercontent.com/u/37784886'],
}

export const config = createConfig({
  chains: [klaytnBaobab],
  transports: {
    [klaytnBaobab.id]: http(),
  },
  connectors: [
    walletConnect({ projectId, metadata, showQrModal: false }),
    injected({ shimDisconnect: true }),
  ],
  ssr: true,
  storage: createStorage({
    storage: cookieStorage,
  }),
})
