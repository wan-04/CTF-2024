import { sqlConnection } from '../app.js';
import timeController from '../system-control.js';

const status = async (req, res) => {
  let results;

  try {
    [results] = await sqlConnection.execute(
      'SELECT * FROM leaps ORDER BY leap_id DESC LIMIT 3');
  } catch (error) {
    results = [];
  }

  const leaps = [];

  results.forEach((leap) => {
    const index = leaps.push(new Date(leap.leap_date));
    leaps[index - 1].setFullYear(leap.year);
  });

  let status = '';
  let statusClass = 'good-status';

  try {
    status = timeController({ type: 'GetStatus' }).status;
  } catch (error) {
    status = error;
    statusClass = 'error';
  };

  res.set('X-Interesting-Header', 'back-in-time flag part 3 of 3: "cijueiF}"');
  res.render('status', {
    session: req.session,
    leaps: leaps,
    status: status,
    statusClass: statusClass
  });
};

export default status;
