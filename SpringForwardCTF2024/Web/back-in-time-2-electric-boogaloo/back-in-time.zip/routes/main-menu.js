const mainMenu = (req, res) => {
  res.render('main-menu', {
    session: req.session
  });
};

export default mainMenu;
