const logout = (req, res) => {
  req.session.user = null
  req.session.save(() => {
    req.session.regenerate(() => {
      res.redirect('/login');
    });
  });
};

export default logout;
