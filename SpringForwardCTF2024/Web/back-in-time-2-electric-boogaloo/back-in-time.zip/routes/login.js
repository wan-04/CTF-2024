import { Router } from 'express';
import { sqlConnection } from '../app.js';

const loginRouter = Router({ mergeParams: true });

loginRouter.get('/', (req, res) => {
  if (req.session.user)
    return res.redirect('/main-menu');

  res.render('login', {
    session: req.session
  });
});

loginRouter.post('/', async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  try {
    const [results] = await sqlConnection.execute(
      'SELECT * FROM users WHERE username="' + username + '" AND password="' + password + '"');

    if (!results[0]) {
      return res.json({ error: 'Invalid username or password.' });
    }

    req.session.regenerate(() => {
      req.session.user = results[0].username;
      req.session.save(() => {
        res.json({ success: true });
      });
    });
  } catch (error) {
    return res.json({ error: 'An error has occured while logging in: ' + error });
  }
});

export default loginRouter;
