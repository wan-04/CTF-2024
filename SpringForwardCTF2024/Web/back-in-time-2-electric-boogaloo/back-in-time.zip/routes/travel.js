import { sqlConnection } from '../app.js';
import timeController from '../system-control.js';
import { Router } from 'express';

const timeTravelRouter = Router({ mergeParams: true });

timeTravelRouter.get('/', async (req, res) => {
  let results;

  try {
    [results] = await sqlConnection.execute(
      'SELECT * FROM leaps ORDER BY leap_id DESC');
  } catch (error) {
    results = null;
  }


  let lastTravelDate;
  if (results.length) {
    const lastTravelEntry = results[0];
    lastTravelDate = new Date(lastTravelEntry.leap_date);
    lastTravelDate.setFullYear(lastTravelEntry.year);
  } else {
    lastTravelDate = new Date('1970-01-01');
  }

  res.render('travel', {
    session: req.session,
    currentDate: new Date(),
    lastTravelDate: lastTravelDate,
    destinationDate: timeController({ type: 'GetSetpoint' }),
  });
});

timeTravelRouter.put('/', async (req, res) => {
  const request = { type: 'SetSetpoint' };

  if (req.body.debug && !(process.env.ALLOW_USER_DEBUG === 'true')) {
    return res.json({ error: 'Debug mode is not allowed to be set.' });
  }

  for (const prop in req.body) {
    request[prop] = req.body[prop];
  }

  const date = new Date(req.body.date);
  let year = req.body.year;
  if (req.body.bc)
    year = year * -1;
  date.setFullYear(year);
  try {
    timeController(request);
    if (request.debug) {
      return res.json({ success: true, debugInfo: process.env.FLAG });
    } else {
      return res.json({ success: true });
    }
  } catch (err) {
    res.status(500);
    if (request.debug) {
      return res.json({ error: err.message, debugInfo: process.env.FLAG });
    } else {
      return res.json({ error: err.message });
    }
  }

});
timeTravelRouter.post('/', async (_req, res) => {
  try {
    timeController({ type: 'TimeTravel' });
    return res.json({ success: true });
  } catch (err) {
    res.status(500);
    return res.json({ error: err.message });
  }
});

export default timeTravelRouter;
