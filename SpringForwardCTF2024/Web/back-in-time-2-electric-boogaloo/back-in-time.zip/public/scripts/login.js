const printError = (errorStr) => {
  document.getElementById('login-error').textContent = errorStr;
};

document.getElementById('login-form').addEventListener('submit', async (evt) => {
  evt.preventDefault();
  printError('Logging in...');

  const request = {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  };

  try {
    const response = await fetch('/login', {
      'headers': {
        'content-type': 'application/json'
      },
      'body': JSON.stringify(request),
      'method': 'post',
      'credentials': 'include'
    }).then((res) => { return res.json() });

    console.log(response);

    if (response.success) {
      window.location.replace('/');
    } else {
      printError(response.error);
    }
  } catch (err) {
    printError('An error has occured while logging in.');
  }
});
