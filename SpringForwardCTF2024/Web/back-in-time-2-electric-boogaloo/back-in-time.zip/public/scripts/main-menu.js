const clock = document.getElementById('clock');

const updateClock = () => {
  clock.innerText = (new Date()).toLocaleString('en-US', {
    month: 'long',
    year: 'numeric',
    weekday: 'long',
    day: '2-digit',
    hour: '2-digit',
    hour12: false,
    minute: '2-digit',
    second: '2-digit',
    era: 'short',
    timeZone: 'America/New_York'
  });
};

updateClock();
setInterval(updateClock, 1000);
