const printError = (errorStr) => {
  document.getElementById('time-travel-status').textContent = errorStr;
};

document.getElementById('set-destination-time').addEventListener('submit', async (evt) => {
  evt.preventDefault();
  printError('Setting destination time...');

  const request = {
    date: document.getElementById('date').value,
    year: document.getElementById('year').value,
    bc: document.getElementById('bc').checked
  };

  try {
    const response = await fetch('/travel', {
      'headers': {
        'content-type': 'application/json'
      },
      'body': JSON.stringify(request),
      'method': 'put',
      'credentials': 'include'
    }).then((res) => { return res.json() });

    console.log(response);

    if (response.success) {
      window.location.reload();
    } else {
      printError(response.error);
    }
  } catch (err) {
    printError('An error has occured while setting destination time.');
  }
});

document.getElementById('time-travel').addEventListener('click', async (evt) => {
  evt.preventDefault();
  printError('Traveling through time...');

  try {
    const response = await fetch('/travel', {
      'method': 'post',
      'credentials': 'include'
    }).then((res) => { return res.json() });

    console.log(response);

    if (response.success) {
      window.location.reload();
    } else {
      printError(response.error);
    }
  } catch (err) {
    printError('An error has occured while traveling through time.');
  }
});
