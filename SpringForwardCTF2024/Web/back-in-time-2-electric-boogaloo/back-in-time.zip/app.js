import express from 'express';
import session from 'express-session';
import mysql from 'mysql2/promise';
import mainMenu from './routes/main-menu.js';
import travel from './routes/travel.js';
import login from './routes/login.js';
import logout from './routes/logout.js';
import status from './routes/status.js';

const app = express();

const port = 80;

export const sqlConnection = await mysql.createConnection({
  host: process.env.SQL_HOST,
  user: process.env.SQL_USERNAME,
  password: process.env.SQL_PASSWORD,
  database: process.env.SQL_DATABASE
});

app.set('view engine', 'ejs');
app.set('views', 'views/pages');
app.use(express.static('public'));
app.use(express.json());
app.use(session({
  secret: 'P6CwJdmGwEaoNKm2',
  resave: false,
  saveUninitialized: false
}));

app.get('/', (req, res) => {
  if (req.session.user) {
    res.redirect('/main-menu');
  } else {
    res.redirect('/login');
  }
});

const checkAuth = (req, res, next) => {
  if (req.session.user) next()
  else res.redirect('/login');
}

app.get('/main-menu', checkAuth, mainMenu);
app.use('/travel', checkAuth, travel);
app.get('/status', checkAuth, status);
app.use('/login', login);
app.get('/logout', logout);

app.listen(port);
console.log('Listening on port: ' + port);
