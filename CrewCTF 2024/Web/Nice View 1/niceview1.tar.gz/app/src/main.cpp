#include "relay.hpp"
#include "settings.hpp"

#include <drogon/drogon.h>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <utility>

using namespace drogon;

std::stringstream makeStream()
{
	std::stringstream ss;
	ss << std::hex << std::setfill('0');
	return ss;
}

std::string randomKey()
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::stringstream ss = makeStream();
	std::uniform_int_distribution dist{0, 255};
	ss.str("");
	for (int i = 0; i < 16; i++) {
		ss << std::setw(2) << dist(gen);
	}
	return ss.str();
}

void logRequest(const HttpRequestPtr& req)
{
	auto q = req->getQuery();
	LOG_INFO << req->getMethodString() << " - " << req->getPeerAddr().toIp() << " - " << req->getOriginalPath()
			 << (q.empty() ? "" : "?" + q);
}

void sendResponse(auto&& callback, drogon::HttpStatusCode code, std::string msg = "")
{
	auto resp = HttpResponse::newHttpResponse();
	if (!msg.empty())
		resp->setBody(msg);
	resp->setStatusCode(code);
	callback(resp);
}

bool checkFileExists(const std::string& s)
{
	if (FILE* f = fopen(s.data(), "r")) {
		fclose(f);
		return true;
	}
	return false;
}

enum BadBadReason
{
	FileOk,
	FileNotExist,
	FileTooBig,
	FileHasBadString,
};

BadBadReason isViewBadBad(const std::string& tmpl)
{
	std::string filename = "./views/d/" + tmpl + ".csp";
	if (!checkFileExists(filename)) {
		return FileNotExist;
	}

	std::ifstream file{filename};
	file.seekg(0, std::ios::end);
	size_t size = file.tellg();
	if (size > GOLF_SIZE) { // Let's go golfing!
		return FileTooBig;
	}
	// Read file.
	std::string buffer(size, ' ');
	file.seekg(0);
	file.read(&buffer[0], size);

	static const std::string badbadstrings[] = {"G",	"D",   "A",	   "E",		 "define", "pragma",
												"##",	"$$",  "c++",  "<<",	 ">>",	   "{%", "view", "layout", "[[", "open",
												"read", "sys", "exec", "stream", "char",   "string"};
	for (const auto& s : badbadstrings)
		if (buffer.find(s) != std::string::npos) {
			// Found.
			return FileHasBadString;
		}

	return FileOk;
}


int main(int, const char*[])
{
	app().loadConfigFile("config.json");

	app().registerHandler("/", [](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback) {
		logRequest(req);
		auto resp = HttpResponse::newHttpViewResponse("upload");
		callback(resp);
	});

	app().registerHandler(
		"/view/{}",
		[](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback, const std::string& page) {
			logRequest(req);

			BadBadReason reason = isViewBadBad(page);
			switch (reason) {
				case FileTooBig: {
					// You should get a 5 iron and go learn from Mr. Woods.
					sendResponse(callback, k418ImATeapot, "file too big");
					break;
				}
				case FileNotExist: {
					// View? What view?
					sendResponse(callback, k404NotFound, "view not found");
					break;
				}
				case FileHasBadString: {
					// UNACCEPTABLE!
					sendResponse(callback, k406NotAcceptable, "file contains bad string");
					break;
				}
				case FileOk: {
					auto resp = HttpResponse::newHttpViewResponse(page);
					callback(resp);
					break;
				}
			}
		});

	app().registerHandler("/upload",
						  [&](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback) {
							  logRequest(req);

							  MultiPartParser fileUpload;
							  if (fileUpload.parse(req) != 0 || fileUpload.getFiles().size() != 1) {
								  sendResponse(callback, k403Forbidden, "Expected one file: score.");
								  return;
							  }

							  auto scoreFile = fileUpload.getFiles()[0];

							  auto key = randomKey();

							  auto path = app().getUploadPath() + "/" + key;
							  LOG_INFO << "saving files to " << path;
							  scoreFile.saveAs(path + "/" INPUT_SCORE_FILENAME);

							  auto score = path + "/" INPUT_SCORE_FILENAME;
							  auto outfile = path + "/" OUTPUT_AUDIO_FILENAME;

							  auto res = synthesise(score, outfile);

							  if (res.wasOk()) {
								  std::cout << "(" << key << "): successfully generated audio" << std::endl;
								  auto resp = HttpResponse::newFileResponse(outfile, "", CT_CUSTOM, "audio/wav");
								  callback(resp);

							  } else {
								  std::cout << "[ERROR] (" << key << ") " << res.getErrorMessage() << std::endl;

								  // It was a server error, but it was your fault to begin with. So let's return a 4xx.
								  // Hmm... I wonder which particular 4xx to use...
								  sendResponse(callback, k418ImATeapot, res.getErrorMessage().toStdString());
							  }
						  },
						  {Post});

	LOG_INFO << "running webserver...";
	app().run();
}